package WeekFiveCTA;

import java.util.Scanner;

/**
 * This program takes five numbers from the user using a scanner object. It
 * keeps checking to make sure the user is actually entering valid integers. If
 * the user types in an incorrect input, they will be asked to enter another
 * number. It will keep asking them to enter a valid input until a valid number
 * is given. Afterwards, all five numbers are entered and stored in an array,
 * and the program uses a recursive method to find the product of all the
 * numbers in the array. The final product will be printed as the output.
 * 
 * Author: Aerionna Stephenson
 * 
 * I used the following source to show me how to use recursion to perform
 * operations on an array:
 * source:https://www.geeksforgeeks.org/dsa/sum-array-elements-using-recursion/
 */
public class multiplyFive {

	/**
	 * recursively multiplies the elements in the array
	 * 
	 * @param arr an array of integers
	 * @param n   an integer that describes the number of elements in the array
	 * @return returns the recursive method or the base case once it approaches the
	 *         last element
	 */
	public static int multiply(int[] arr, int n) {
		// checks if there are no more elements in the array to multiply
		if (n <= 0) {
			// returning 1 ensures that the product will not be affected
			return 1; // base case
		} else { // by default if n > 0
			// this will multiply the first n-1 elements times the last current element
			return multiply(arr, n - 1) * arr[n - 1];
		}
	}

	/**
	 * In the main method, a scanner object is initialized. The user is prompted to
	 * input five integers. These integers are then saved into an array and the
	 * recursive multiply method is applied to the array. The result is going to be
	 * a product of all the numbers in the array.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		int[] arr = new int[5];
		System.out.print("Please enter 5 numbers.");

		for (int i = 0; i < arr.length; i++) {
			// input validation: ensure that the user is entering integers
			while (true) {
				if (scanner.hasNextInt()) {
					arr[i] = scanner.nextInt();
					break;
				} else {
					System.out.println("This input is invalid. Please enter a number.");
					scanner.next();
				}
			}
		}

		System.out.println(multiply(arr, arr.length) + " is the product of the 5 numbers that you entered.");

	}

}
